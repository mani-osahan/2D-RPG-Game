pass
pass
pass
pass
a = None
b = 1
c = None
d = 1
e = 1
f = 1
aa = None
aaa = None
A = 1
B = 1
C = 1
class D:
	pass
pass
pass
def foo():
	pass
def bar():
	pass
