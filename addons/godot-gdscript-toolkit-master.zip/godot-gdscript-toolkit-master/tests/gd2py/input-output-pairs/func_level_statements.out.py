def foo():
	pass
	a = None
	b = 1
	c = None
	d = 1
	e = 1
	1
	if 1:
		pass
	elif 1:
		pass
	else:
		pass
	while 1:
		break
	for i in 1:
		continue
	for j in 1:
		continue
	if 1:
		pass
	elif 1:
		pass
	elif 1:
		pass
	return
	return 1
