# Change Log

### 1.2.3

Allow the use of defaultInterpreterPath to control python path

### 1.2.2

Fix formatter issue

### 1.2.1

Fix scripts saving even when autosave was false

### 1.2

Fix save on format

### 1.1.2

Add the ability to update the pip package natively

### 1.1.1

Take the python path from VSCode configuration

### 1.1.0

Add the `Organize Script` and `Convert multiline comment blocks to #` commands.

Fix a bug that caused the last character, if it wasn't a newline, to repeat.

### 1.0.2

Fix to the README markdown and package.json

### 1.0.0

Initial release of the VSCode extension of GDScript Formatter.
