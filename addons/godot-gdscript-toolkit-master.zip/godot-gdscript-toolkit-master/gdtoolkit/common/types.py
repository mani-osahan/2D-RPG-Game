from typing import Union

from lark import Tree, Token

Node = Union[Tree, Token]
