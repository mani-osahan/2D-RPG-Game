from dataclasses import dataclass


@dataclass
class Range:
    begin: int
    end: int
